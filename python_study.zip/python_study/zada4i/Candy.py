class Candy:
    def __init__(self, name, price, weight):
        self.name = name
        self.price = price
        self.weight = weight
    
class Chocolate(Candy):
    def __init__(self, cocoa_percentage, chocolate_type):
        self.cocoa_percentage = cocoa_percentage
        self. chocolate_type = chocolate_type

class Gummy(Candy):
    def __init__(self, flavor, shape):
        self.flavor = flavor
        self.shape = shape
    
class HardCandy(Candy):
    def __init__(self, flavor, filled):
        self.flavor = flavor
        self.filled = filled
        