class Zhenya:
    __slots__ = ['name', 'age']
    
    def __init__(self, name, age):
        if (name == 'Евгений'):
            self.name = name
        else:
            self.name = f" Я не {name}, а Евгений!"
        self.age = age

z = Zhenya('Васян', 15)
print(z.name)