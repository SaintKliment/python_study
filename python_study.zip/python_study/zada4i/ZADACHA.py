class check_sim:
    def __init__(self, x):
        self.x = x
    
    def check_num(self):
        self.number = self.x
        symbols_to_remove1 = "kohmsM"
    
        for symbol1 in symbols_to_remove1:
            self.number = self.number.replace(symbol1, "")
        
        self.number = int(self.number)
        return self.number
    
    def check_str(self):
        self.string_txt = self.x
        symbols_to_remove = "1234567890"

        for symbol in symbols_to_remove:
            self.string_txt = self.string_txt.replace(symbol, "")
        
        return self.string_txt
    
    def preobrazovanie(self):
        if self.string_txt[0] == 'k':
            self.number = self.number * 1000
        elif self.string_txt[0] == 'M':
            self.number = self.number * 1000000
        return self.number
 
    def res_colors(self):
        self.res_colors = []

    def create_list(self):
        while self.number >= 1:
            
    
c = check_sim('2134M ohms')
print(c.check_num())
print(c.check_str())
print(c.preobrazovanie())