class TriangleCheacker:
    def __init__(self, a, b, c):
        self.a = a  
        self.b = b
        self.c = c

    def Checker(self):
        if (self.a > 0 and self.b > 0 and self.c > 0):
            if (self.a < self.b + self.c and self.b < self.a + self.c and self.c < self.a + self.b):
                return("Треугольник существует ;)")
            else:
                return("Такой треугольник не существует")
        else:
            return("Стороны не могут быть отрицательными!!!")

check = TriangleCheacker(8, 10, 1)
print(check.Checker())