class Animal:
    def __init__(self, name, species, leg):
        self.name = name
        self.species = species
        self.leg = leg

    def voice(self):
        return('Uugh!')

    def move(self):
        return('doing step')

class Dog(Animal):
    def __init__(self, breed):
        self.breed = breed
    
    def bark(self):
        return("ГАВ!")

class Bird(Animal):
    def __init__(self, wingspan):
        self.wingspan = wingspan

    def fly(self):
        return('Птичка пребывает в полете!')

a = Animal('bobik', '4ih', 4 )
b = Bird(20)
d = Dog('persil')
print(d.bark())
print(b.fly())