class BankAccount:
    
    history_number = 0
    list_transactions = []
    history_str = ""

    def __init__(self, balance, interest_rate):
        self._balance = balance
        self._interest_rate = interest_rate

    def __str__(self):
        return(f"{self._balance}, {self._interest_rate}")

    def set_global_variable(self):
        global history_number
        global list_transactions
        global history_str 

    def deposit(self, amount):
        self._balance += amount
        self.history_number += 1
        self.history_str = (f'{self.history_number} transaction. Deposit a sum of money: {amount}. Balance: {self._balance}.')
        self.list_transactions.append(self.history_str)
        #print(self.history_number)
        #print(self.list_transactions)
        return self.history_str


    def withdraw(self, amount):
        self._balance -= amount   
        self.history_number += 1     
        self.history_str = (f'{self.history_number} transaction. Withdraw a sum of money: {amount}. Remainder: {self._balance}.')
        self.list_transactions.append(self.history_str)
        #print(self.history_number)
        #print(self.list_transactions)
        return self.history_str

    def add_interest(self):
        self._balance = (self._balance + ((self._balance/100) * self._interest_rate))
        self.history_number += 1     
        self.history_str = (f'{self.history_number} transaction. Interest rate bonus credited: {self._balance}. ')
        self.list_transactions.append(self.history_str)
        return self.list_transactions

    def history(self):
        print("History:")
        return self.list_transactions

a = BankAccount(1000, 15)
print(str(a))
print(a.deposit(100))
print(a.withdraw(100))
print(a.add_interest())
print(a.history())