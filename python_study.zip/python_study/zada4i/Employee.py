class Employee:

    def __init__(self, name, age, salary):
        self.name = name
        self.age = age
        self.salary = salary

    def get_name(self):
        return(f"Name: {self.name}")
    
    def get_age(self):
        return(f"Age: {self.age}")

    def get_salary(self):
        return(f"Salary: {self.salary}")

    def set_bonus(self, bonus):
        self.bonus = bonus

    def get_bonus(self):
        self.salary = self.salary + self.bonus
        return self.salary
    
    def get_total_salary(self):
        return(f"Total salary is {self.salary}")

a = Employee('Petya', 20, 15000)
a.set_bonus(3000)
a.get_bonus()
print(a.get_total_salary())