class Soldier:

    def __init__(self, name, rank, service_number):
        self.name = name
        self._rank = rank
        self._service_number = service_number
        self.i = 0
  
    def get_rank(self):
        self.ranks = ['Рядовой', 'Ефрейтор', 'Младший сержант', 'Сержант', 'Старший сержант', 'Старшина', 'Прапорщик', 'Старший прапорщик']  
        self._rank = self.ranks[0]
        return (f"Ваше звание: {self._rank}")

    def confirmation_ser_num(self):
        if (self._service_number == 1):
            return('Номер подтвержден')
        else:
            raise('Error: неверный номер')
    
    def up_rank(self):
        self.i += 1
        self.rank = self.ranks[self.i]
        return (f'Ваше звание повышено: {self.rank}')

    def d_rank(self):
        self.i -= 1
        self.rank = self.ranks[self.i]
        return (f'Ваше звание понижено: {self.rank}')

s = Soldier('name', '-', 1)
print(s.get_rank())
print(s.confirmation_ser_num())
print(s.up_rank())
print(s.up_rank())
print(s.d_rank())
