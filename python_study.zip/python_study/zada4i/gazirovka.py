class Soda:
    def __init__(self, arg = None):
        if (arg, str):
            self.arg = arg
        else:
            self.arg = None

    def show_my_drink(self):
        if self.arg:
            return(f"Газировка и {self.arg}")
        else:
            return("Обычная газировка")

s = Soda('ГРЕЧКА')
print(s.show_my_drink())