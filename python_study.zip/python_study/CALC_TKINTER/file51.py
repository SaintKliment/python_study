from tkinter import * 

root =  Tk()

def Hello(event):
    print("1")

btn = Button(root,
             text = "CLICK ME",
             width = 30, height = 5,
             bg = "white", fg = "black",)
btn.bind("<Button-1>", Hello)
btn.pack()
root.mainloop()

