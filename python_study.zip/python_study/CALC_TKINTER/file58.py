from tkinter import *
from tkinter import messagebox

def show_message():
    #messagebox.showinfo("musercorp sender", "Авторизация успешно завершена")
    global num
    num = (message.get())

root = Tk()
root.title("musercorp sender")
root.geometry("300x250")
 
message = StringVar()
 
message_entry = Entry(textvariable=message) #Поле ввода
message_entry.place(relx=.5, rely=.1, anchor="c")
 
message_button = Button(text="Отправить первый элемент", command=show_message) #Кнопка
message_button.place(relx=.5, rely=.5, anchor="c")

root.mainloop()