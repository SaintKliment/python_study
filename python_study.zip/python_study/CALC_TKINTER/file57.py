from tkinter import *

root = Tk()
var = StringVar()
var.set('hello')

l = Entry(root, textvariable = var)
l.pack()

t = Label(root, textvariable = var)
t.pack()

root.mainloop()

"""




"""