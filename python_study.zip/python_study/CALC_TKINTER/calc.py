class Calculate:
    def reshenie(self):
        self.formula = '0'
        self.lbl = Label(text=self.formula, font=("Times New Roman", 21, "bold"), bg="#000", foreground="#FFF")


        


c = Calculate()
c.estimation_numb1()
c.num1()
c.num2()
c.plus()
print(c.plus())

