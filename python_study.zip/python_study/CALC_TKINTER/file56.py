from tkinter import *

root = Tk()
l1 = Label(text="Число", width=30)
b1 = Button(text="1", )
b2 = Button(text='2', )
b3 = Button(text='3', )
b4 = Button(text='4', )
b5 = Button(text='5', )
b6 = Button(text='6', )
b7 = Button(text='7', )
b8 = Button(text='8', )
b9 = Button(text='9', )
b0 = Button(text='0', )
plus = Button(text='+')
minus = Button(text='-')
delitel = Button(text='/')
mutliple = Button(text='*')
rav = Button(text='=')



class Calculation():
    global list_num
    list_num = []
    global list_plus 
    list_plus = []
    global itog
    itog = ''
    global opred1
    global opred2
    global opred3
    global opred4
    opred1 = 0
    opred2 = 0
    opred3 = 0
    opred4 = 0

    def change1(self):
        i = str(1)
        list_num.append(i)
        self.outputStr = (''.join(map(str, list_num)))
        l1['text'] = self.outputStr


    def change2(self):
        i = str(2)
        list_num.append(i)
        self.outputStr = (''.join(map(str, list_num)))
        l1['text'] = self.outputStr

    def change3(self):
        i = str(3)
        list_num.append(i)
        self.outputStr = (''.join(map(str, list_num)))
        l1['text'] = self.outputStr

    def change4(self):
        i = str(4)
        list_num.append(i)
        self.outputStr = (''.join(map(str, list_num)))
        l1['text'] = self.outputStr

    def change5(self):
        i = str(5)
        list_num.append(i)
        self.outputStr = (''.join(map(str, list_num)))
        l1['text'] = self.outputStr

    def change6(self):
        i = str(6)
        list_num.append(i)
        self.outputStr = (''.join(map(str, list_num)))
        l1['text'] = self.outputStr

    def change7(self):
        i = str(7)
        list_num.append(i)
        self.outputStr = (''.join(map(str, list_num)))
        l1['text'] = self.outputStr

    def change8(self):
        i = str(8)
        list_num.append(i)
        self.outputStr = (''.join(map(str, list_num)))
        l1['text'] = self.outputStr

    def change9(self):
        i = str(9)
        list_num.append(i)
        self.outputStr = (''.join(map(str, list_num)))
        l1['text'] = self.outputStr

    def change0(self):
        i = str(0)
        list_num.append(i)
        self.outputStr = (''.join(map(str, list_num)))
        l1['text'] = self.outputStr


    def plus(self):
        global opred1
        global opred2
        global opred3
        global opred4
        global list_num
        global list_plus
        self.numberInt = int(self.outputStr)
        list_plus.append(self.numberInt)
        l1['text'] = f'{self.outputStr} +'
        list_num = [self.numberInt, ' + ', ]
        opred1 = 1

    def minus(self):
        global opred1
        global opred2
        global opred3
        global opred4
        global list_num
        global list_plus
        self.numberInt = int(self.outputStr)
        list_plus.append(self.numberInt)
        l1['text'] = f'{self.outputStr} -'
        list_num = [self.numberInt, ' - ', ]
        opred2 = 1

    def delitel(self):
        global opred1
        global opred2
        global opred3
        global opred4
        global list_num
        global list_plus
        self.numberInt = int(self.outputStr)
        list_plus.append(self.numberInt)
        l1['text'] = f'{self.outputStr} /'
        list_num = [self.numberInt, ' / ', ]
        opred3 = 1

    def multiple(self):
        global opred1
        global opred2
        global opred3
        global opred4
        global list_num
        global list_plus
        self.numberInt = int(self.outputStr)
        list_plus.append(self.numberInt)
        l1['text'] = f'{self.outputStr} *'
        list_num = [self.numberInt, ' * ', ]
        opred4 = 1


    def rav(self):
        del (list_num[0])
        del (list_num[0])
        self.outputStr = (''.join(map(str, list_num)))
        self.numbetInt2 = int(self.outputStr)
        if opred1 == 1:
            itog = int (self.numberInt + self.numbetInt2)
        elif opred2 == 1: 
            itog = int (self.numberInt - self.numbetInt2)
        elif opred3 == 1: 
            itog = int (self.numberInt / self.numbetInt2)
        elif opred4 == 1 : 
            itog = int (self.numberInt * self.numbetInt2)
        self.outputStr = str(itog)

        l1['text'] = itog


c = Calculation()

b1.config(command = c.change1)
b2.config(command = c.change2)
b3.config(command = c.change3)
b4.config(command = c.change4)
b5.config(command = c.change5)
b6.config(command = c.change6)
b7.config(command = c.change7)
b8.config(command = c.change8)
b9.config(command = c.change9)
b0.config(command = c.change0)
plus.config(command = c.plus)
minus.config(command = c.minus)
delitel.config(command = c.delitel)
mutliple.config(command = c.multiple)
rav.config(command = c.rav)

l1.pack()
b1.pack()
b2.pack()
b3.pack()
b4.pack()
b5.pack()
b6.pack()
b7.pack()
b8.pack()
b9.pack()
b0.pack()
plus.pack()
minus.pack()
delitel.pack()
mutliple.pack()
rav.pack()

root.mainloop()