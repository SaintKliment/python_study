a1 = float(input('Введите первый аргумент: '))
znak = input('Введите знак операции(*, /, -, +): ')
a2 = float(input('Введите второй аргумент: '))
a3 = 0
if znak == '+':
    a3 = a1 + a2
    print(f'Результат равен {a3}')
elif znak == '-':
    a3 = a1 - a2
    print(f'Результат равен {a3}')
elif znak == '/':
    a3 = a1 / a2
    print(f'Результат равен {a3}')
elif znak == '*':
    a3 = a1 * a2
    print(f'Результат равен {a3}')
    