class Student:
    def __init__(self, name, marks):
        self.name = name
        self.marks = list(marks)

    def __getitem__(self, item):
        print('__getitem__')
        if 0 <= item < len(self.marks):
            return self.marks[item]
        else:
            raise IndexError('Неверный индекс')
    
    def __setitem__(self, key, value):
        print('__setitem__')
        if not isinstance(key, int) or key < 0:
            raise TypeError('Индекс должен быть целым и положительным')
        if key >= len(self.marks):
            off = key + 1 - len(self.marks)
            self.marks.extend([None] * off)
        
        self.marks[key] = value

    def __delitem__(self, key):
        if not isinstance(key, int):
            raise TypeError('Индекс должен быть целым и положительным')
        
        del self.marks[key]


s = Student('Евгений', [4, 5, 4, 5, 5])
#s[7] = 5
del s[2]
print(s.marks)