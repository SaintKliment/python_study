try:
    f = open('myFile2.txt')
except FileNotFoundError:
    print("невозможно открыть файл")

print('Штатное завершение')