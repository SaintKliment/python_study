try:
    x, y = map(int, input().split())
    res = x / y
except (ValueError, ZeroDivisionError):
    print("значение должно быть интовым")
# except ZeroDivisionError:
    # print('деление на ноль')

print('Штатное завершение')