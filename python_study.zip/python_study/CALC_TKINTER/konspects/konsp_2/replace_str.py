class StringChars:
    def __init__(self, chars):
        self.__count = 0
        self.__chars = chars

    def __call__(self, *args, **kwargs):
        if not isinstance(args[0], str):
            raise TypeError('аргумент должен быть строкой')
        
        return args[0].strip(self.__chars)

c = StringChars("!/.#?")
new = c("??#Hello world!")
print(new)