
class Points:  # создание класса



    def __init__(self, x,y,z): #  инициализация

        self.coords = [x,y,z]



    def __str__(self):  # применяется, если объект класса делают строкой

        return (f'Координаты точки:\n'+

                f'X = {self.coords[0]}\n'+

                f'Y = {self.coords[1]}\n'+

                f'Z = {self.coords[2]}')

 

    def _operate(first,other,action):

        if isinstance(other, (int, float)):  # проверяет тип второго аргумента

            return Points((eval(f'{first.coords[0]} {action} {other}')),

                          (eval(f'{first.coords[1]} {action} {other}')),

                          (eval(f'{first.coords[2]} {action} {other}')))

        elif type(other) == Points:  # позволит прибавлять к объекту другой объект класса

            return Points((eval(f'{first.coords[0]} {action} {other.coords[0]}')),

                          (eval(f'{first.coords[1]} {action} {other.coords[1]}')),

                          (eval(f'{first.coords[2]} {action} {other.coords[2]}')))

        else:

            raise TypeError('второй аргумент должен быть числом или объектом класса')



    def __add__(self, other):  # вызывается, если к объекту класса применить сложение

        return self._operate(other, '+')



    def __sub__(self, other):  # вызывается, если к объекту класса применить вычитание

        return self._operate(other, '-')



    def __mul__(self, other):  # вызывается, если к объекту класса применить умножение

        return self._operate(other, '*')



    def __truediv__(self, other):  # вызывается, если к объекту класса применить деление

        return self._operate(other, '/')







point1 = Points(16,42,12)

point2 = Points(1,1,1)

point3 = Points(3,3,3)

point4 = point1 * point3 - point2

print(point4)
