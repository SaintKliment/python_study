sum = int(input('Введите сумму в рублях: '))
dollar = sum / 89
evro = sum / 97
opred = input('Введите знак валюты, в который хотите конвертировать($ или €): ')
if (opred == '$'):
    print(f'Это будет {dollar} долларов')
if (opred == '€'):
    print(f'Это будет {evro} евро')
