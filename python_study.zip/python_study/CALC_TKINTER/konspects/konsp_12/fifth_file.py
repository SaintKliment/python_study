price_maintenance = int(input('Введите сумму, потраченную на ТО за год: '))
price_fuel = float(input('Введите стоимость топлива руб/литр: '))
transport_tax = int(input('Введите транспортный налог: '))
insurance = int(input('Введите сумму страховки: '))
S_year = int(input('Введите пробег за год: '))
summa = price_maintenance + (price_fuel * (12.4 *(S_year/100))) + insurance + transport_tax
print(f'Стоимость содержания вашего автомобиля составляет целых {summa: .2f} рублей!!!')
