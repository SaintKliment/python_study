from pprint import pprint

import requests

data = requests.get('https://www.cbr-xml-daily.ru/daily_json.js').json()
usd = (data['Valute']['USD']['Value'])
eur = (data['Valute']['EUR']['Value'])
sum = int(input('Введите сумму, которую вы хотите конвертировать: '))
choice = input('Введите валюту, в которую хотите конвертировать(eur or usd): ')
eur1 = sum / eur
usd1 = sum / usd

if (choice == 'eur'):
    print(f'Это будет {eur1: .2f} евро.')
if (choice == 'usd'):
    print(f'Это будет {usd1: .2f} долларов.')

