s = '1234423455'
print(s.isdigit())
