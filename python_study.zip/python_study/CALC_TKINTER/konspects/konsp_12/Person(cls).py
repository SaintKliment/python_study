from string import ascii_letters

class Person:

    s_rus = 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя-'
    s_rus_upper = s_rus.upper()

    def __init__(self, name, age, ps, weight):
        self.verify_name(name)

        self.__name = name
        self.age = age
        self.ps = ps
        self.weight = weight

    @classmethod
    def verify_name(cls, name):
        if type(name) != str:
            raise TypeError('ФИО должно быть строкой')
        
        n = name.split()

        if len(n) != 3:
            raise TypeError('Неверный формат записи')
        
        letters = ascii_letters + cls.s_rus + cls.s_rus_upper

        for i in n:
            if len(i) < 1:
                raise TypeError('В ФИО должен быть хотя бы 1 символ')
            if len(i.strip(letters)) != 0:
                raise TypeError('В ФИО можно использовать лишь буквенные символы и дефис')
            
    @classmethod
    def verify_age(cls, age):
        if type(age) != int or age < 14 or age > 120:
            raise TypeError('Возраст должен быть целым числом в диапозоне [14; 120]')
        
    @classmethod
    def verify_weight(cls, weight):
        if type(weight) != float or weight < 20 :
            raise TypeError('Вес должен быть вещественным числом от 20 и выше')

    @classmethod
    def verify_ps(cls, ps):
        if type(ps) != str:
            raise TypeError('Паспорт должен быть строкой')
        
        psl = ps.split()
        if len(psl) != 2 or len(psl[0]) != 4 or len(psl[1]) != 6:
            raise TypeError('Неверный формат паспорта')
        for i in psl:
            if not i.isdigit():
                raise TypeError('Серия и номер паспорта должны быть числами')
            
        
    @property
    def name(self):
        return self.__name
    
    @property
    def age(self):
        return self.__age
    
    @age.setter
    def age(self, age):
        self.verify_age(age)
        self.__age = age

    @property
    def weight(self):
        return self.__weight
    
    @weight.setter
    def weight(self, weight):
        self.verify_weight(weight)
        self.__weight = weight

    @property
    def ps(self):
        return self.__ps
    
    @ps.setter
    def ps(self, ps):
        self.verify_ps(ps)
        self.__ps = ps


p = Person('Урядов Евгений Алексеевич', 30, '1234 123456', 80.0)
p.age = 100
p.ps ='4576 123456'
p.weight = 70.0
print(p.__dict__)


