class Geom:
    pass

class Line(Geom):
    pass 

g = Geom()
l = Line()
print(issubclass(list, object))