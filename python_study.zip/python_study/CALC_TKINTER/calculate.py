from tkinter import * 

root =  Tk()

class Calculate:  
    def __init__(self):
        pass

   

c = Calculate()

l1 = Label(text="0", width=30)
btn_1 = Button(root, text = '1', )
btn_1.grid(row = 1, column = 1)
btn_2 = Button(root, text = '2', )
btn_2.grid(row = 1, column = 2)
btn_3 = Button(root, text = '3', )
btn_3.grid(row = 1, column = 3)
btn_4 = Button(root, text = '4', )
btn_4.grid(row = 2, column = 1)
btn_5 = Button(root, text = '5', )
btn_5.grid(row = 2, column = 2)
btn_6 = Button(root, text = '6', )
btn_6.grid(row = 2, column = 3)
btn_7 = Button(root, text = '7', )
btn_7.grid(row = 3, column = 1)
btn_8 = Button(root, text = '8', )
btn_8.grid(row = 3, column = 2)
btn_9 = Button(root, text = '9', )
btn_9.grid(row = 3, column = 3)
btn_0 = Button(root, text = '0', )
btn_0.grid(row = 4, column = 1, columnspan = 3)
btn_plus = Button(root, text = '+', )
btn_plus.grid(row = 1, column = 4)
btn_minus = Button(root, text = '-', )
btn_minus.grid(row = 2, column = 4)
btn_multiple = Button(root, text = '*', )
btn_multiple.grid(row = 3, column = 4)
btn_divide = Button(root, text = '/', )
btn_divide.grid(row = 4, column = 4)

btn_1.bind("<Button-1>",)
btn_plus.bind("<Button-1",)
l1.pack()
root.mainloop()