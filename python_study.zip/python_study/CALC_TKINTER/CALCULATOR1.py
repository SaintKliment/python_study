from tkinter import *


root = Tk()
l1 = Label(text="", width=10)
b1 = Button(text="1", width=3, height=3)
b2 = Button(text='2', width=3, height=3)
b3 = Button(text='3', width=3, height=3)
b4 = Button(text='4', width=3, height=3)
b5 = Button(text='5', width=3, height=3)
b6 = Button(text='6', width=3, height=3)
b7 = Button(text='7', width=3, height=3)
b8 = Button(text='8', width=3, height=3)
b9 = Button(text='9', width=3, height=3)
b0 = Button(text='0', width=3, height=3)
plus = Button(text='+', width=3, height=3)
minus = Button(text='-', width=3, height=3)
divide = Button(text='/', width=3, height=3)
mutliple = Button(text='*', width=3, height=3)
rav = Button(text='=', width=3, height=3)


class Calculation():
    def __init__(self):
        super().__init__()
        self.build()

    def build(self):
        self.formula = ""

    def change1(self):
        self.formula += '1'
        l1['text'] = self.formula
    
    def change2(self):
        self.formula += '2'
        l1['text'] = self.formula

    def change3(self):
        self.formula += '3'
        l1['text'] = self.formula

    def change4(self):
        self.formula += '4'
        l1['text'] = self.formula

    def change5(self):
        self.formula += '5'
        l1['text'] = self.formula

    def change6(self):
        self.formula += '6'
        l1['text'] = self.formula

    def change7(self):
        self.formula += '7'
        l1['text'] = self.formula

    def change8(self):
        self.formula += '8'
        l1['text'] = self.formula

    def change9(self):
        self.formula += '9'
        l1['text'] = self.formula

    def change0(self):
        self.formula += '0'
        l1['text'] = self.formula

    def plus(self):
      self.formula += '+'
      l1['text'] = self.formula
    
    def minus(self):
      self.formula += '-'
      l1['text'] = self.formula

    def divide(self):
      self.formula += '/'
      l1['text'] = self.formula

    def multiple(self):
      self.formula += '*'
      l1['text'] = self.formula

   
    def rav(self):
        self.formula = str(eval(self.formula))
        l1['text'] = self.formula

c = Calculation()

b1.config(command = c.change1)
b2.config(command = c.change2)
b3.config(command = c.change3)
b4.config(command = c.change4)
b5.config(command = c.change5)
b6.config(command = c.change6)
b7.config(command = c.change7)
b8.config(command = c.change8)
b9.config(command = c.change9)
b0.config(command = c.change0)
plus.config(command = c.plus)
minus.config(command = c.minus)
divide.config(command = c.divide)
mutliple.config(command = c.multiple)
rav.config(command = c.rav)



l1.grid(row=0, column=2, columnspan=4)
b1.grid(row=1, column=1)
b2.grid(row=1, column=2)
b3.grid(row=1, column=3)
b4.grid(row=2, column=1)
b5.grid(row=2, column=2)
b6.grid(row=2, column=3)
b7.grid(row=3, column=1)
b8.grid(row=3, column=2)
b9.grid(row=3, column=3)
b0.grid(row=4, column=1, columnspan=3, ipadx=60)
plus.grid(row=1, column=4)
minus.grid(row=2, column=4)
divide.grid(row=3, column=4)
mutliple.grid(row=4, column=4)
rav.grid(row=5, column=1, columnspan=4, ipadx=90)

root.title("Калькулятор")

root.mainloop()

