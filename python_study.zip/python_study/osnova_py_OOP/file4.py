class SomeClass(object):
    @staticmethod
    def hello():
        print('hello')
SomeClass.hello()
obj = SomeClass()
obj.hello()