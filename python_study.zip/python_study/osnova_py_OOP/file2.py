class Point(object):
    def __init__(self, x, y, z):
        self.coord = (x, y, z)
p = Point(13, 14, 15)
print (p.coord)