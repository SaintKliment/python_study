hours = str(input("Введите часы по порядку:"))
orders = str(input("Введите кол-во заказов по порядку: "))
 
list_h = hours.split()
list_o = orders.split()

 
expression_list_h = '+'.join(list_h)
expression_list_o = '+'.join(list_o)
 
res_hours = eval(expression_list_h)
res_orders = eval(expression_list_o)
 
salary_hours = 250 * res_hours
salary_orders = 400 * res_orders
salary_sum_del_len = (salary_hours + salary_orders) / 2
 
strSalaryHours = f'Ваша зарплата по часам равна {salary_hours}'
strSalaryOrders = f'Ваша зарплата по заказам равна {salary_orders}'
strSalary_s = f'Ваша зарплата ср по з и ч {salary_sum_del_len}'

 
print(strSalaryHours)
print(strSalaryOrders)
print(strSalary_s)