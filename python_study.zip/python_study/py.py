# s = '01234567891011121314151617'
# for i in range(0, len(s), 5):
#     print(s[i], end='')

# newList = []
# b = 0

# for i in range(1, 11, 1):
#     a = str(input())
#     reverse_a = a[::-1]
#     b -= 1
#     newList.insert(b, reverse_a)

# print(newList)

# a = str(input())
# b = str(input())
# newList = []
# newList.append(a)
# newList.append(b)
# print(-len(newList))

import random

m = 7
n = 5

matrix = [[random.randint(0,100) for j in range(m)] for i in range(n)]
# print(matrix)

for i in matrix:
  print(i, end="\n")

print(matrix[0][6])

max = 0
for i in matrix[0]:
  if i > max:
    max = i
print(max)

# for i in range(len(matrix)):
#   for j in range(len(matrix[i])):
#     print(matrix[i][j], end='\n')

# for i in range(len(matrix)):
#   for j in range(len(matrix[i])):
#     print(matrix[i][j], end='\n')