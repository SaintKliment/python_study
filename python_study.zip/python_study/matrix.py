# import random

# m = 7
# n = 5
# matrix = [[random.randint(0, 100) for j in range (m)] for i in range(n)]
# for i in matrix:
#   print(i, end='\n')
# print(matrix)

# for i in range(len(matrix)):
#   for j in range(len(matrix[i])):
#     matrix[i][j] 



# from functools import reduce
# from operator import mul

# newList1 = [1, 2, 2, 2, 3]
# newList = reduce(mul, newList1, 100)
# newListMin= reduce(min, newList1)
# newListMax= reduce(max, newList1)

# for i in newList1:
#   print(i, end='\n')

# print('кол-во элемс: ', len(newList1))
# print(newListMax)
# print(newListMin)
# print(newList)
# print(sum(newList1))

# def func1(a, b):
#   sum = a + b
#   print('sum = ', sum)
#   print('вы ввели параметр ',a, b)
# func1(123, 45)



# def greetings(st):
#      print(st)
#      if len(st) == 0:  # Граничный случай
#          return             
#      else:       # Рекурсивный случай
#          greetings(st[:-1])   

# greetings('Hello, world!')

# def greetings2(st):
#   print(st)
#   if len(st) > 0:
#     greetings(st[:-1])
# greetings2('hello, petya')

# def primer:
#   primer()



# # Определение функции, которая пытается поделить число на ноль
# def divide(x, y):
#     result = x / y
#     return result
# # Вызов функции divide с передачей ей x=5 и y=0
# try:
#     result = divide(5, 0)
#     print(f"Result of dividing : {result}")
# except ZeroDivisionError:
#     print("Cannot divide by zero.")
# except TypeError:
#     print("тип плохой")



# def name(name):
#  return(print('твоё имя равно', name))
# name('petya')

# newList = [1, 2, 3, 4]

# for i in range(len(newList)):
#   print(newList[i])

# for i in newList:
#   print(i)

# import numpy as np
# squareMatrix = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
# upperTriangle = np.triu(squareMatrix)
# lowerTriangle = np.tril(squareMatrix)
# diagonalTriangle = np.diag(squareMatrix)
# print(squareMatrix)
# print('upperTriangle')
# print(upperTriangle)
# print('lowerTriangle')
# print(lowerTriangle)
# print('diagonalTriangle')
# print(diagonalTriangle)


# newList = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# resSlice = newList[0:9:2] # [start:end:step]
# print(resSlice)

# newList = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# newList.append(111)
# secondList = [123, 321]
# newList.extend(secondList)
# newList.insert(0, 1000)
# newList.pop(0) # без параметра удаляет ласт значение
# print(newList)

my_list = [1, 2, 3, 4, 5]
item = 3
print(item)
if item in my_list:
    print("Desired item is in list")
else