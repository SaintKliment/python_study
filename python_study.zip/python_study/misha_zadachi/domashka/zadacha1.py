class Preob:
    def __init__(self, text):
        self.text = text
    
    def dePreob(self):
        self.words = self.text.split()
        return (','.join(str(el) for el in  self.words))

p = Preob('принимать песни люблю я')
print(p.dePreob())