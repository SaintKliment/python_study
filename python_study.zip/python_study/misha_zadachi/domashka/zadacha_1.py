text = str(input("Введите строчку: "))
words = text.split()
print(','.join(map(str, words)))

text1 = ['Преобразование','c', 'помощью','цикла']
words1 = ''
for elem in text1:
    words1 += str(elem)
    words1 += ','
print(words1)