text = str(input('Введите строку: '))
text1 = text.replace('w', '')
new_text = text1.replace('z', '')
print(new_text)