a = int(input())
b = int(input())
c = int(input())
if a % 2 != 0:
    a += 1
a = a // 2
if b % 2 != 0:
    b += 1
b = b // 2
if c % 2 != 0:
    c += 1
c = c // 2
sum = (a+b+c) 
print(sum)
